// Code By Thoai
#include <WiFi.h>
#include <JPEGDEC.h>
#include <LovyanGFX.hpp>
#include "esp_heap_caps.h"

const char* ssid = "SSID";
const char* password = "PASS";

#define MAX_BUFFER_SIZE (128 * 1024)
#define READ_CHUNK_SIZE 4096

class LGFX : public lgfx::LGFX_Device {
  lgfx::Panel_ST7789 _panel;
  lgfx::Bus_Parallel8 _bus;
  lgfx::Light_PWM _light;

public:
  LGFX() {
    {
      auto cfg = _bus.config();
      cfg.freq_write = 20000000;
      cfg.pin_wr = 8;
      cfg.pin_rd = 9;
      cfg.pin_rs = 7;
      cfg.pin_d0 = 39;
      cfg.pin_d1 = 40;
      cfg.pin_d2 = 41;
      cfg.pin_d3 = 42;
      cfg.pin_d4 = 45;
      cfg.pin_d5 = 46;
      cfg.pin_d6 = 47;
      cfg.pin_d7 = 48;
      _bus.config(cfg);
      _panel.setBus(&_bus);
    }

    {
      auto cfg = _panel.config();
      cfg.pin_cs = 6;
      cfg.pin_rst = 5;
      cfg.pin_busy = -1;
      cfg.memory_width = 240;
      cfg.memory_height = 320;
      cfg.panel_width = 170;
      cfg.panel_height = 320;
      cfg.offset_x = 35;
      cfg.offset_y = 0;
      cfg.offset_rotation = 2;
      cfg.dummy_read_pixel = 8;
      cfg.dummy_read_bits = 1;
      cfg.readable = false;
      cfg.invert = true;
      cfg.rgb_order = false;
      cfg.dlen_16bit = false;
      cfg.bus_shared = false;
      _panel.config(cfg);
    }

    {
      auto cfg = _light.config();
      cfg.pin_bl = 38;
      cfg.invert = false;
      cfg.freq = 44100;
      cfg.pwm_channel = 7;
      _light.config(cfg);
      _panel.setLight(&_light);
    }
    setPanel(&_panel);
  }
};

LGFX tft;
JPEGDEC jpeg;
WiFiServer server(8080);
WiFiClient client;

uint8_t* frameBuffer = nullptr;

int JPEGDraw(JPEGDRAW *pDraw) {
  tft.pushImage(pDraw->x, pDraw->y, pDraw->iWidth, pDraw->iHeight,
                (uint16_t*)pDraw->pPixels);
  return 1;
}

void setup() {
  Serial.begin(115200);
  delay(500);

  if (psramFound()) {
    Serial.println("[INFO] Co PSRAM");
  } else {
    Serial.println("[INFO] Khong co PSRAM");
  }

  Serial.printf("[INFO] Free heap: %u bytes\n", ESP.getFreeHeap());

  tft.init();
  tft.setRotation(1);
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setTextDatum(lgfx::middle_center);
  tft.drawString("Thoai", tft.width() / 2, tft.height() / 2);
  delay(2000);

  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextDatum(lgfx::top_left);
  tft.setCursor(5, 5);
  tft.setTextSize(1);
  tft.println("Connecting WiFi...");

  frameBuffer = (uint8_t*)heap_caps_malloc(MAX_BUFFER_SIZE, MALLOC_CAP_INTERNAL);
  if (!frameBuffer) {
    Serial.println("[ERR] Khong du RAM noi de cap phat buffer!");
    tft.fillScreen(TFT_RED);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setCursor(5, 5);
    tft.println("RAM FAIL!");
    while (1) delay(100);
  }
  Serial.printf("[OK] Buffer cap phat: %u bytes\n", MAX_BUFFER_SIZE);
  Serial.printf("[INFO] Free heap sau cap phat: %u bytes\n", ESP.getFreeHeap());

  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  Serial.println("[OK] WiFi connected");
  Serial.print("[OK] IP: ");
  Serial.println(WiFi.localIP());

  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setCursor(5, 5);
  tft.print("IP: ");
  tft.println(WiFi.localIP());

  server.begin();
  Serial.println("[OK] TCP server port 8080");
  Serial.println("San sang nhan stream...");
}

void loop() {
  if (!client || !client.connected()) {
    client = server.available();
    if (client) {
      Serial.println("[OK] Client da ket noi");
    }
    delay(10);
    return;
  }

  if (client.available() >= 4) {
    uint32_t jpegSize;
    client.readBytes((char*)&jpegSize, 4);

    if (jpegSize == 0 || jpegSize > MAX_BUFFER_SIZE) {
      Serial.printf("[WARN] Kich thuoc JPEG khong hop le: %u\n", jpegSize);
      client.stop();
      return;
    }

    uint32_t bytesRead = 0;
    uint32_t timeout = millis() + 2000;

    while (bytesRead < jpegSize && millis() < timeout) {
      if (client.available()) {
        int toRead = min((uint32_t)client.available(), jpegSize - bytesRead);
        int r = client.read(frameBuffer + bytesRead, toRead);
        if (r > 0) bytesRead += r;
      } else {
        delay(1);
      }
    }

    if (bytesRead == jpegSize) {
      uint32_t t0 = millis();
      if (jpeg.openRAM(frameBuffer, jpegSize, JPEGDraw)) {
        jpeg.setPixelType(RGB565_BIG_ENDIAN);
        jpeg.decode(0, 0, 0);
        jpeg.close();
        uint32_t dt = millis() - t0;
        Serial.printf("[OK] Decode %u bytes trong %u ms\n", jpegSize, dt);
      } else {
        Serial.println("[ERR] JPEG openRAM that bai");
      }
    } else {
      Serial.printf("[WARN] Timeout: %u/%u bytes\n", bytesRead, jpegSize);
    }
  }
}