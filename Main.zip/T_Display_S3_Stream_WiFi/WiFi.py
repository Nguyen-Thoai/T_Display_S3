# Code By Thoai
import sys
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import socket
import struct
import time
import io
import ctypes
import threading
import queue
import traceback
from ctypes import wintypes

import numpy as np
from PIL import Image, ImageDraw
import mss

ESP32_IP = "192.168.1.100"  # Thay đổi địa chỉ IP của ESP32 tại đây

class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class CURSORINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("hCursor", wintypes.HANDLE),
        ("ptScreenPos", POINT),
    ]


CURSOR_SHOWING = 0x00000001
user32 = ctypes.windll.user32


def get_cursor_info():
    ci = CURSORINFO()
    ci.cbSize = ctypes.sizeof(CURSORINFO)
    if user32.GetCursorInfo(ctypes.byref(ci)):
        return bool(ci.flags & CURSOR_SHOWING), ci.ptScreenPos.x, ci.ptScreenPos.y
    return False, 0, 0


_CURSOR_IMG = None


def get_cursor_bitmap():
    global _CURSOR_IMG
    if _CURSOR_IMG is not None:
        return _CURSOR_IMG

    W = max(8, int(14 * 0.7))
    H = max(10, int(20 * 0.7))

    canvas = Image.new("RGBA", (W * 4, H * 4), (0, 0, 0, 0))
    d = ImageDraw.Draw(canvas)

    k = 4 * (W / 14.0)
    pts = [
        (0  * k, 0  * k),
        (0  * k, 16 * k),
        (4  * k, 12 * k),
        (7  * k, 20 * k),
        (11 * k, 18 * k),
        (7  * k, 11 * k),
        (14 * k, 11 * k),
    ]
    ow = max(1, int(4 * 0.4))
    d.polygon(pts, fill=(255, 255, 255, 255), outline=(0, 0, 0, 255))
    d.line(pts + [pts[0]], fill=(0, 0, 0, 255), width=ow, joint="curve")

    _CURSOR_IMG = canvas.resize((W, H), Image.LANCZOS)
    return _CURSOR_IMG


def draw_cursor(img, monitor, cursor_x, cursor_y):
    sx = img.width / monitor["width"]
    sy = img.height / monitor["height"]
    x = int((cursor_x - monitor["left"]) * sx)
    y = int((cursor_y - monitor["top"]) * sy)

    if not (0 <= x < img.width and 0 <= y < img.height):
        return

    c = get_cursor_bitmap()
    img.paste(c, (x, y), c)

frame_q = queue.Queue(maxsize=2)
send_q  = queue.Queue(maxsize=4)

def capture_thread(sct, monitor, stop_evt):
    frame_time = 1.0 / 10
    while not stop_evt.is_set():
        t0 = time.time()
        try:
            sct_img = sct.grab(monitor)
            arr = np.frombuffer(sct_img.bgra, dtype=np.uint8).reshape(
                sct_img.height, sct_img.width, 4)
            rgb = arr[:, :, [2, 1, 0]].copy()
        except Exception as e:
            print(f"[CAPTURE] error: {type(e).__name__}: {e!r}")
            stop_evt.set()
            return

        try:
            frame_q.put((rgb, monitor), timeout=0.5)
        except queue.Full:
            pass

        dt = time.time() - t0
        if dt < frame_time:
            time.sleep(frame_time - dt)

def encode_thread(stop_evt):
    resample = Image.LANCZOS
    while not stop_evt.is_set():
        try:
            rgb, monitor = frame_q.get(timeout=0.5)
        except queue.Empty:
            continue

        try:
            img = Image.fromarray(rgb, "RGB")
            img = img.resize((320, 170), resample)

            visible, cx, cy = get_cursor_info()
            if visible:
                draw_cursor(img, monitor, cx, cy)

            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=90,
                     optimize=False, subsampling=2)
            data = buf.getvalue()

            if len(data) > 128 * 1024:
                new_q = max(40, 90 - 25)
                buf = io.BytesIO()
                img.save(buf, format="JPEG", quality=new_q,
                         optimize=False, subsampling=2)
                data = buf.getvalue()
        except Exception as e:
            print(f"[ENCODE] error: {type(e).__name__}: {e!r}")
            stop_evt.set()
            return

        try:
            send_q.put(data, timeout=0.5)
        except queue.Full:
            pass

def send_thread(sock, stop_evt):
    stats_n = 0
    stats_t = time.time()
    last_kb = 0.0
    while not stop_evt.is_set():
        try:
            data = send_q.get(timeout=0.5)
        except queue.Empty:
            continue

        header = struct.pack("<I", len(data))
        try:
            sock.sendall(header + data)
        except (ConnectionResetError, ConnectionAbortedError,
                BrokenPipeError, OSError) as e:
            print(f"[SEND] network error: {type(e).__name__}: {e!r}")
            stop_evt.set()
            return
        except BaseException as e:
            print(f"[SEND] unexpected: {type(e).__name__}: {e!r}")
            stop_evt.set()
            raise

        stats_n += 1
        last_kb = len(data) / 1024.0
        if stats_n % 30 == 0:
            elapsed = time.time() - stats_t
            if elapsed > 0:
                fps = stats_n / elapsed
                try:
                    qsize = send_q.qsize()
                except Exception:
                    qsize = -1
                print(f"Queue: {qsize} | FPS: {fps:.1f} | JPEG: {last_kb:.1f} KB")

def _guard(name, fn):
    def inner(*a, **kw):
        try:
            fn(*a, **kw)
        except BaseException:
            print(f"\n[THREAD {name}] crashed:")
            traceback.print_exc()
    return inner

def main():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 256 * 1024)
    try:
        sock.connect((ESP32_IP, 8080))
        print(f"Đã kết nối ESP32 {ESP32_IP}:{8080}")
    except Exception as e:
        print(f"Lỗi kết nối: {e!r}")
        return

    stop_evt = threading.Event()

    try:
        sct = mss.MSS()
    except AttributeError:
        sct = mss.mss()

    try:
        monitor = sct.monitors[1]

        t_cap = threading.Thread(
            target=_guard("capture", capture_thread),
            args=(sct, monitor, stop_evt), daemon=True)
        t_enc = threading.Thread(
            target=_guard("encode", encode_thread),
            args=(stop_evt,), daemon=True)
        t_snd = threading.Thread(
            target=_guard("send", send_thread),
            args=(sock, stop_evt), daemon=True)

        t_cap.start()
        t_enc.start()
        t_snd.start()

        try:
            while not stop_evt.is_set():
                time.sleep(0.5)
        except KeyboardInterrupt:
            print("\nĐã dừng stream.")

    finally:
        stop_evt.set()
        time.sleep(0.3)
        try:
            sock.close()
        except Exception:
            pass
        try:
            sct.close()
        except Exception:
            pass

if __name__ == "__main__":
    main()