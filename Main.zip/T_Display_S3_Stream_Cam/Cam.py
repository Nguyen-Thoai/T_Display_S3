# Code By Thoai
import serial, struct, cv2, time, threading
import numpy as np

PORT  = 'COM1'  # Thay đổi cổng COM của ESP32 tại đây

_idx_cache = {}
def calc_checksum(data: bytes) -> int:
    n = len(data)
    if n not in _idx_cache:
        _idx_cache[n] = ((np.arange(n) & 3) * 8).astype(np.uint32)
    shifts = _idx_cache[n]
    arr = np.frombuffer(data, dtype=np.uint8).astype(np.uint32)
    return int(np.bitwise_xor.reduce(arr << shifts)) & 0xFFFFFFFF

latest = None
lock = threading.Lock()
stop = False

def cam_worker():
    global latest
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)
    cap.set(cv2.CAP_PROP_FPS, 30)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    while not stop:
        ok, f = cap.read()
        if not ok:
            continue
        f = cv2.resize(f, (320, 170), interpolation=cv2.INTER_AREA)
        f = cv2.flip(f, 1)
        with lock:
            latest = f
    cap.release()

threading.Thread(target=cam_worker, daemon=True).start()

ser = serial.Serial(PORT, 2000000, timeout=1, write_timeout=1)
time.sleep(2)
ser.reset_input_buffer()

enc_params = [cv2.IMWRITE_JPEG_QUALITY, 70]

frame_count = 0
t0 = time.time()

try:
    while True:
        if b'RDY' not in ser.readline():
            continue

        with lock:
            frame = None if latest is None else latest.copy()
        if frame is None:
            continue

        ok, buf = cv2.imencode('.jpg', frame, enc_params)
        if not ok:
            continue
        data = buf.tobytes()
        cs   = calc_checksum(data)

        packet = b'\xAA\x55\xAA\x55' + struct.pack('<I', len(data)) + data + struct.pack('<I', cs)
        ser.write(packet)

        frame_count += 1
        if frame_count % 24 == 0:
            dt = time.time() - t0
            print(f"FPS: {24/dt:5.1f} | {len(data)*24/dt/1024:6.1f} KB/s")
            t0 = time.time()
finally:
    stop = True
    ser.close()