// Code By Thoai
#include <JPEGDEC.h>
#include <LovyanGFX.hpp>
#include "esp_heap_caps.h"

#define MAX_BUFFER_SIZE (128 * 1024)
#define SERIAL_BAUD 2000000

class LGFX : public lgfx::LGFX_Device {
  lgfx::Panel_ST7789 _panel;
  lgfx::Bus_Parallel8 _bus;
  lgfx::Light_PWM _light;
public:
  LGFX() {
    {
      auto cfg = _bus.config();
      cfg.freq_write = 20000000;
      cfg.pin_wr = 8;
      cfg.pin_rd = 9;
      cfg.pin_rs = 7;
      cfg.pin_d0 = 39;
      cfg.pin_d1 = 40;
      cfg.pin_d2 = 41;
      cfg.pin_d3 = 42;
      cfg.pin_d4 = 45;
      cfg.pin_d5 = 46;
      cfg.pin_d6 = 47;
      cfg.pin_d7 = 48;
      _bus.config(cfg);
      _panel.setBus(&_bus);
    }
    {
      auto cfg = _panel.config();
      cfg.pin_cs = 6;  cfg.pin_rst = 5; cfg.pin_busy = -1;
      cfg.memory_width = 240;
      cfg.memory_height = 320;
      cfg.panel_width = 170;
      cfg.panel_height = 320;
      cfg.offset_x = 35;
      cfg.offset_y = 0;
      cfg.offset_rotation = 2;
      cfg.dummy_read_pixel = 8;
      cfg.dummy_read_bits = 1;
      cfg.readable = false;
      cfg.invert = true;
      cfg.rgb_order = false;
      cfg.dlen_16bit = false;
      cfg.bus_shared = false;
      _panel.config(cfg);
    }
    {
      auto cfg = _light.config();
      cfg.pin_bl = 38;
      cfg.invert = false;
      cfg.freq = 44100;
      cfg.pwm_channel = 7;
      _light.config(cfg);
      _panel.setLight(&_light);
    }
    setPanel(&_panel);
  }
};

LGFX tft;
JPEGDEC jpeg;
uint8_t* frameBuffer = nullptr;

int JPEGDraw(JPEGDRAW *pDraw) {
  tft.pushImage(pDraw->x, pDraw->y, pDraw->iWidth, pDraw->iHeight,
                (uint16_t*)pDraw->pPixels);
  return 1;
}

bool readExact(uint8_t* buf, uint32_t len, uint32_t timeoutMs) {
  uint32_t got = 0;
  uint32_t deadline = millis() + timeoutMs;
  while (got < len) {
    if (millis() >= deadline) return false;
    int avail = Serial.available();
    if (avail > 0) {
      int toRead = min((uint32_t)avail, len - got);
      int r = Serial.readBytes(buf + got, toRead);
      if (r > 0) got += r;
    } else {
      yield();
    }
  }
  return true;
}

void resync() {
  Serial.println("[RESYNC]");
  unsigned long deadline = millis() + 500;
  while (millis() < deadline) {
    if (Serial.available()) {
      Serial.read();
      deadline = millis() + 50;
    } else {
      yield();
    }
  }
}

void setup() {
  Serial.setRxBufferSize(16384);
  Serial.begin(SERIAL_BAUD);
  delay(500);

  tft.init();
  tft.setRotation(1);

  frameBuffer = (uint8_t*)heap_caps_malloc(MAX_BUFFER_SIZE, MALLOC_CAP_INTERNAL);
  if (!frameBuffer) {
    tft.fillScreen(TFT_RED);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setCursor(5, 5);
    tft.setTextSize(1);
    tft.println("RAM FAIL!");
    while (1) delay(100);
  }

  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextDatum(lgfx::middle_center);
  tft.setTextSize(2);
  tft.drawString("Thoai", tft.width() / 2, tft.height() / 2);
  delay(2000);

  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextDatum(lgfx::top_left);
  tft.setCursor(5, 5);
  tft.setTextSize(1);
  tft.println("USB Ready");

  while (Serial.available()) Serial.read();
}

void loop() {
  uint32_t jpegSize;
  if (!readExact((uint8_t*)&jpegSize, 4, 500)) return;

  if (jpegSize < 100 || jpegSize > MAX_BUFFER_SIZE) {
    resync();
    return;
  }

  if (!readExact(frameBuffer, 2, 500)) {
    resync();
    return;
  }

  if (frameBuffer[0] != 0xFF || frameBuffer[1] != 0xD8) {
    resync();
    return;
  }

  if (!readExact(frameBuffer + 2, jpegSize - 2, 3000)) {
    resync();
    return;
  }

  if (jpeg.openRAM(frameBuffer, jpegSize, JPEGDraw)) {
    jpeg.setPixelType(RGB565_BIG_ENDIAN);
    tft.startWrite();
    if (!jpeg.decode(0, 0, 0)) {
      Serial.println("[DECODE FAIL]");
    }
    tft.endWrite();
    jpeg.close();
  }
}