# Code By Thoai
import serial
import struct
import time
import io
import ctypes
from ctypes import wintypes
from PIL import Image, ImageDraw
import mss

ESP32_PORT = "COM1"  # Thay đổi cổng COM của ESP32 tại đây

class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]

class CURSORINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("hCursor", wintypes.HANDLE),
        ("ptScreenPos", POINT),
    ]

CURSOR_SHOWING = 0x00000001
user32 = ctypes.windll.user32

def get_cursor_info():
    ci = CURSORINFO()
    ci.cbSize = ctypes.sizeof(CURSORINFO)
    if user32.GetCursorInfo(ctypes.byref(ci)):
        return bool(ci.flags & CURSOR_SHOWING), ci.ptScreenPos.x, ci.ptScreenPos.y
    return False, 0, 0

_CURSOR_IMG = None

def get_cursor_bitmap():
    global _CURSOR_IMG
    if _CURSOR_IMG is not None:
        return _CURSOR_IMG

    W = max(8, int(14 * 0.7))
    H = max(10, int(20 * 0.7))

    canvas = Image.new("RGBA", (W * 4, H * 4), (0, 0, 0, 0))
    d = ImageDraw.Draw(canvas)

    k = 4 * (W / 14.0)
    pts = [
        (0  * k, 0  * k),
        (0  * k, 16 * k),
        (4  * k, 12 * k),
        (7  * k, 20 * k),
        (11 * k, 18 * k),
        (7  * k, 11 * k),
        (14 * k, 11 * k),
    ]
    ow = max(1, int(4 * 0.4))
    d.polygon(pts, fill=(255, 255, 255, 255), outline=(0, 0, 0, 255))
    d.line(pts + [pts[0]], fill=(0, 0, 0, 255), width=ow, joint="curve")

    _CURSOR_IMG = canvas.resize((W, H), Image.LANCZOS)
    return _CURSOR_IMG

def draw_cursor(img, monitor, cursor_x, cursor_y):
    sx = img.width / monitor["width"]
    sy = img.height / monitor["height"]
    x = int((cursor_x - monitor["left"]) * sx)
    y = int((cursor_y - monitor["top"]) * sy)

    if not (0 <= x < img.width and 0 <= y < img.height):
        return

    c = get_cursor_bitmap()
    img.paste(c, (x, y), c)

def main():
    try:
        ser = serial.Serial(ESP32_PORT, 2000000, timeout=1)
        time.sleep(2)
    except Exception as e:
        print(f"Lỗi mở cổng: {e}")
        return

    with mss.mss() as sct:
        monitor = sct.monitors[1]
        frame_time = 1.0 / 10
        frame_count = 0
        last_report = time.time()

        try:
            while True:
                start_time = time.time()

                sct_img = sct.grab(monitor)
                img = Image.frombytes("RGB", sct_img.size, sct_img.bgra, "raw", "BGRX")
                img = img.resize((320, 170), Image.LANCZOS)

                visible, cx, cy = get_cursor_info()
                if visible:
                    draw_cursor(img, monitor, cx, cy)

                buffer = io.BytesIO()
                img.save(buffer, format="JPEG", quality=90, optimize=False, subsampling=2)
                jpeg_data = buffer.getvalue()

                header = struct.pack("<I", len(jpeg_data))
                ser.write(header + jpeg_data)

                frame_count += 1
                if time.time() - last_report >= 2:
                    fps = frame_count / (time.time() - last_report)
                    print(f"FPS: {fps:.1f}")
                    frame_count = 0
                    last_report = time.time()

                elapsed = time.time() - start_time
                if elapsed < frame_time:
                    time.sleep(frame_time - elapsed)

        except KeyboardInterrupt:
            print("\nĐã dừng stream.")
        finally:
            ser.close()

if __name__ == "__main__":
    main()